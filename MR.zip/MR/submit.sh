cd /appl/MR/mapreduce
client submit@jobconf@fuck@wordcount.dis@wctest@out@3@20000@9@6@2@1
client start@0
