cd /appl/MR
dfs/dfsserver&
dfs/dfsnodeserver&
