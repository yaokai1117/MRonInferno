rm -rf task/*
rm cli/*
rm cli/remote/*
rm ser/*
rm ser/remote/*
rm hostser/*
rm hostser/remote/*
rm mapreduce/log*
